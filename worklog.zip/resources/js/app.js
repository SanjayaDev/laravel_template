// Import bootstrap js from node_modules
import 'bootstrap';