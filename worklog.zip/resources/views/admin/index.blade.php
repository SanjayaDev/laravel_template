<x-layouts.admin.app :title="$title" :breadcrumb="$breadcrumb">

  <div class="card">
    <div class="card-body">
      <h4>Halo</h4>
    </div>
  </div>

</x-layouts.admin.app>