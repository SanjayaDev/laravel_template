<div class="form-group">
  <label><?php echo e($label); ?></label>
  <textarea name="<?php echo e($name); ?>" class="form-control" cols="30" rows="<?php echo e($rows ?? 10); ?>"><?php echo e($value ?? ''); ?></textarea>
</div><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/components/forms/textarea-group.blade.php ENDPATH**/ ?>