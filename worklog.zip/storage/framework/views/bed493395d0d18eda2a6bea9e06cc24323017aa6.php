<footer class="mt-5">
  <div class="footer clearfix mb-0 text-muted">
      <div class="float-start">
          <p><?php echo e(date("Y")); ?> &copy; Mazer</p>
      </div>
      
  </div>
</footer><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/components/layouts/admin/footer.blade.php ENDPATH**/ ?>