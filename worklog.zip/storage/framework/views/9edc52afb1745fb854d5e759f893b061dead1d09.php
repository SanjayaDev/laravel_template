<div id="sidebar" class="active">
  <div class="sidebar-wrapper active">
      <div class="sidebar-header">
          <div class="d-flex justify-content-between">
              <div class="logo">
                
              </div>
              <div class="toggler">
                  <a href="#" class="sidebar-hide d-xl-none d-block"><i class="fas fa-close"></i></a>
              </div>
          </div>
      </div>
      <div class="sidebar-menu">
          <ul class="menu">
              <li class="sidebar-title">Menu</li>

              <li class="sidebar-item <?php echo e($title == "Dashboard" ? 'active' : ''); ?>">
                  <a href="/dashboard" class='sidebar-link'>
                      <i class="fas fa-dashboard"></i>
                      <span>Dashboard</span>
                  </a>
              </li>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('check-module', '002U')): ?>
                <li class="sidebar-item <?php echo e($title == "Users Management" ? 'active' : ''); ?>">
                  <a href="/dashboard/users" class='sidebar-link'>
                    <i class="fas fa-users"></i>
                    <span>Users</span>
                  </a>
                </li> 
              <?php endif; ?>

              <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('check-module', '003PJ')): ?>
                <li class="sidebar-item <?php echo e($title == "Projects Management" ? 'active' : ''); ?>">
                  <a href="/dashboard/projects" class='sidebar-link'>
                    <i class="fas fa-walkie-talkie"></i>
                    <span>Projects</span>
                  </a>
                </li> 
              <?php endif; ?>

              <li class="sidebar-item">
                <form action="/logout" method="POST">
                  <?php echo csrf_field(); ?>
                  <button class='btn-hide border-none w-100 sidebar-link'>
                    <i class="fas fa-sign-out"></i>
                    <span>Logout</span>
                  </button>
                </form>
              </li>

              

          </ul>
      </div>
      <button class="sidebar-toggler btn x"><i data-feather="x"></i></button>
  </div>
</div><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/components/layouts/admin/sidebar.blade.php ENDPATH**/ ?>