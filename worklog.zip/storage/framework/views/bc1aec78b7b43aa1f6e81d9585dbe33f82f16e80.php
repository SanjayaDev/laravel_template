<?php if (isset($component)) { $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\Admin\App::class, ['title' => $title,'breadcrumb' => $breadcrumb] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
 
  <ul class="nav nav-tabs">
    <li class="nav-item">
      <a class="nav-link active" data-bs-toggle="tab" href="#userTab">User</a>
    </li>
    <li class="nav-item">
      <a class="nav-link" data-bs-toggle="tab" href="#moduleAccessTab">Module Access</a>
    </li>
  </ul>

  <div class="card">
    <div class="card-body">
      <div class="tab-content">
        <div class="tab-pane container active" id="userTab">
          <table class="table table-bordered table-responsive">
            <thead>
              <tr>
                <th>Name</th>
                <th>Email</th>
                <th>Action</th>
              </tr>
            </thead>
            <tbody>
              <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                  <td><?php echo e($user->name); ?></td>
                  <td><?php echo e($user->email); ?></td>
                  <td>
                    <a href="<?php echo e(dashboard_url('users/' . $user->id)); ?>" class="btn btn-primary btn-sm">Detail</a>
                  </td>
                </tr>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                  <td colspan="3" class="text-center">No Data</td>
                </tr>
              <?php endif; ?>
            </tbody>
          </table>

          <?php echo e($users->links()); ?>

        </div>
        <div class="tab-pane container fade" id="moduleAccessTab">
          <form action="<?php echo e(dashboard_url('')); ?>roles/<?php echo e($role->id); ?>/module/assign" method="POST">
            <?php echo csrf_field(); ?>
            <?php echo method_field("PUT"); ?>
            <table class="table table-bordered table-responsive">
              <thead>
                <tr>
                  <th>Module Code</th>
                  <th>Module Name</th>
                  <th>Descrition</th>
                  <th>Assigned</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                <?php if($role->id == 1): ?>
                  <tr>
                    <td colspan="4" class="text-center">Super admin is allowed all modules</td>
                  </tr>
                <?php else: ?>
                  <?php $__currentLoopData = $module_exists; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $module): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                      <td><?php echo e($module->module_code); ?></td>
                      <td><?php echo e($module->module_name); ?></td>
                      <td><?php echo e($module->module_description); ?></td>
                      <td>
                        <?php echo e(count($module->module_roles) > 0 ? "Assign" : "-"); ?>

                      </td>
                      <td>
                        <div class="form-check">
                          <input class="form-check-input" type="checkbox" name="module_id[]" value="<?php echo e($module->id); ?>" <?php echo e(count($module->module_roles) > 0 ? "checked" : ""); ?>>
                          <label class="form-check-label">Assign</label>
                        </div>
                      </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php endif; ?>
              </tbody>
            </table>

            <button class="btn btn-success btn-sm mt-3" type="submit">Update</button>
          </form>
        </div>
      </div>
    </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16)): ?>
<?php $component = $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16; ?>
<?php unset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/admin/roles/show.blade.php ENDPATH**/ ?>