<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="ie=edge">
  <meta type="CSRF-TOKEN" value="<?php echo e(csrf_token()); ?>">
  <title><?php echo e($title ?? "Dashboard"); ?></title>
  <link rel="stylesheet" href="<?php echo e(asset('css/app.css')); ?>">
  <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
  <?php echo $__env->yieldPushContent('styles'); ?>

</head>
<body>

  <div id="app">

    <?php echo $__env->make('components.layouts.admin.sidebar', ["title" => $title ?? "Dashboard", "is_su" => $is_su], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div id="main">
      <header class="mb-3">
          <a href="#" class="burger-btn d-block d-xl-none">
            <i class="fas fa-bars"></i>
          </a>
      </header>

      <div class="page-heading">
        <h3><?php echo e($title ?? "Dashboard"); ?></h3>
      </div>
      <div class="page-content">

        <?php echo $breadcrumb; ?>


        <?php echo e($slot); ?>


      </div>

      <?php echo $__env->make('components.layouts.admin.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
</div>

<script src="<?php echo e(asset('js/app.js')); ?>"></script>
<script src="<?php echo e(asset('js/script.js')); ?>"></script>
<?php echo $__env->make('sweetalert::alert', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldPushContent("script"); ?>

</body>
</html><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/components/layouts/admin/app.blade.php ENDPATH**/ ?>