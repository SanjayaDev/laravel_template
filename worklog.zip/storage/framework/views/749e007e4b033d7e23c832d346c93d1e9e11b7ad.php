<?php if (isset($component)) { $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\Admin\App::class, ['title' => $title,'breadcrumb' => $breadcrumb] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  
  <div class="card">
    <div class="card-body">
      <form action="/dashboard/users" method="POST">
        <?php echo csrf_field(); ?>

        <?php echo $__env->make('admin.users.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <button class="btn btn-primary btn-sm mt-3" type="submit">Tambah</button>
      </form>
    </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16)): ?>
<?php $component = $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16; ?>
<?php unset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/admin/users/create.blade.php ENDPATH**/ ?>