<?php if (isset($component)) { $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\Admin\App::class, ['title' => 'User Detail'] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  
  <div class="card">
    <div class="card-body">
      <a href="/dashboard/users/<?php echo e($user->id); ?>/edit" class="btn btn-info btn-sm mb-2">Edit</a>
      <table class="table table-responsive">
        <tr>
          <th>Name</th>
          <td><?php echo e($user->name); ?></td>
        </tr>
        <tr>
          <th>Email</th>
          <td><?php echo e($user->email); ?></td>
        </tr>
        <tr>
          <th>Role</th>
          <td><?php echo e($user->role->role_name); ?></td>
        </tr>
      </table>
    </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16)): ?>
<?php $component = $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16; ?>
<?php unset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/admin/users/show.blade.php ENDPATH**/ ?>