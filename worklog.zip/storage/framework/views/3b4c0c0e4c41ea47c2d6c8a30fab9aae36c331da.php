<div class="form-group">
  <label><?php echo e($label); ?></label>
  <input type="<?php echo e($type ?? 'text'); ?>" class="form-control" name="<?php echo e($name); ?>" id="<?php echo e($idCustom ?? ''); ?>" value="<?php echo e($value ?? ''); ?>">
  <?php $__errorArgs = [$name];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
    <small class="text-danger"><?php echo e($message); ?></small>
  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
</div><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/components/forms/input-group.blade.php ENDPATH**/ ?>