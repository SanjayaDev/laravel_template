<?php if (isset($component)) { $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16 = $component; } ?>
<?php $component = $__env->getContainer()->make(App\View\Components\Layouts\Admin\App::class, ['title' => $title,'breadcrumb' => $breadcrumb] + (isset($attributes) ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('layouts.admin.app'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $constructor = (new ReflectionClass(App\View\Components\Layouts\Admin\App::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
  
  <div class="card">
    <div class="card-body">
      <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('check-module', '002UA')): ?>
        <a href="<?php echo e(dashboard_url('users/create')); ?>" class="btn btn-success btn-sm mb-3">Tambah</a>
      <?php endif; ?>
      <?php if(Auth::user()->role_id == 1): ?>
        <a href="<?php echo e(dashboard_url('roles')); ?>" class="btn btn-success btn-sm mb-3">Roles</a>
      <?php endif; ?>

      <table class="table table-bordered w-100 table-responsive">
        <thead>
          <tr>
            <th>No</th>
            <th>Name</th>
            <th>Email</th>
            <th>Role</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
            <tr>
              <td><?php echo e($loop->iteration); ?></td>
              <td><?php echo e($user->name); ?></td>
              <td><?php echo e($user->email); ?></td>
              <td><?php echo e($user->role->role_name); ?></td>
              <td>
                <a href="<?php echo e(dashboard_url('users/'.$user->id.'/edit')); ?>" class="btn btn-info btn-sm">Edit</a>
              </td>
            </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
            <tr>
              <td colspan="5" class="text-center">No Data</td>
            </tr>
          <?php endif; ?>
        </tbody>
      </table>

      <?php echo e($users->links()); ?>

    </div>
  </div>

 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16)): ?>
<?php $component = $__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16; ?>
<?php unset($__componentOriginal3eb48bef76afbeefe1f360c3cf2b8c42870f0d16); ?>
<?php endif; ?><?php /**PATH C:\laragon\www\laravel\worklog\resources\views/admin/users/index.blade.php ENDPATH**/ ?>